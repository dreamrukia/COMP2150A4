class Node
  attr_accessor :value
  attr_accessor :nxt
  
  def initialize(value, nxt)
    @value = value
    @nxt = nxt
  end
  
end