Run the program using the command:

ruby main.rb

Sometimes it will have some 'require' errors on some computer. I think it should be the ruby version problem.
This version works fine on my computer. If happended some problem like "cannot load such file". Have a try to change the require part by adding ".rb" at the end, or "./" at the front.
It takes time to run the program, please be patient.
I have tested for some small txt file and large txt file. When the file is very large, it may takes lots of time.
But works great on small txt files.